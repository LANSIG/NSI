import turtle as tt
from random import choice

def tirerMot ():
    """
    Cette fonction renvoi un mot tiré au hasard dans un fichier de 837 mots.
    Pour que cette fonction fonctionne correctement, il faut que le fichier fonctionsNSI
    soit dans le meme dossier que le fichier listeMotsPendu.csv. 
    """
    #ouverture du fichier contenant les mots
    textFile = open("listeMotsPendu.csv",'r')
    #conversion en liste
    listMots = textFile.read().split(";")
    #retourne un mot au hasard
    return(choice(listMots))

def traitPendu(n):
    """
    Cette fonction trace le trait N°n.
    Elle peut tracer les traits dans n'importe quel ordre.
    """
    #unité du dessin
    u = 50
    #liste de tous les points de départ des traits:
    xd = [-u*4, -u*2, -u*2, 0, u, u, u, u, u, u, u]
    yd = [-u*4, -u*4, u*3, u*3, u*3, 0, 0, -u, -u, -u*2, -u*2]
    #liste de tous les points d'arrivée des traits:
    xa = [u, -u*2, u*2, -u*2, u, 0, u, -u*0.7, u*2.7, -u/2, u*2.5]
    ya = [-u*4, u*3, u*3, u, u*2, 0, -u*2, 0, 0, -u*3.5, -u*3.5]
    
    tt.hideturtle() #pour cacher la tortue
    tt.pensize(5.5)

    #on va au point de départ crayon levé
    tt.up()
    tt.goto(xd[n-1],yd[n-1])
    #on va au point d'arrivée crayon baissé
    tt.down()
    if n == 6:
        #car le trait 6 est un cercle
        tt.circle(u)
    elif 1 <= n <= 11:
        tt.goto(xa[n-1],ya[n-1])

def saisie ():
    """
    Demande une lettre au joueur. La demande est refaite si le joueur tape plus d'un caractère.
    La lettre tapée est renvoyée en majuscule.
    """
    while True:
        rep = input("Proposez une lettre ")
        #une seule lettre
        if len(rep) == 1:
            #retourne la lettre en majuscule
            return rep.upper()

def testLettre(let, lstMotMyst, lstRep):
    """
    
    """
    if let in lstMotMyst:
        for i in range(len(lstMotMyst)):
            if lstMotMyst[i] == let:
                lstRep[i] = let
        return True
    return False

def testMotTrouve(lstRep):
    """
    Retourne True si le mot est entièrement découvert, False sinon.
    """
    if '_' in lstRep:
            return False
    return True

def lst2str(lst):
    ch = ""
    for u in lst:
        ch += u
    return ch

def recommencer ():
    """
    Demande si il veut une nouvelle partie. La question est reposée si la réponse n'est pas o, O, n, N.
    Cette fonction renvoi True si le joueur veut recommencer et False sinon.
    """
    while True:
        rep = input("Voulez-vous rejouer (O/N) ? ")
        if rep in 'OoyY':
            return True
        if rep in 'Nn':
            return False


def jeuDuPendu ():
   
    print("Bienvenue dans le jeu du pendu\n")

    jouerEncore = ...
    while jouerEncore:
        
        print("Nouvelle partie\n")
        #tirer un mot au hasard
        ...
        #Créer la liste reponse contenant autant de '_' que de lettre dans le mot mystère
        ...
        #initialiser la variable qui compte les traits du pendu (erreurs)
        etape = ...
        #initialiser la fenètre turtle
        tt.clear()
        
        partieFinie = ...
        while not partieFinie:
            print(F"On joue avec le mot de {...} lettres : {...}")
            lettre = ...
            if ... :
                print(F"Bravo ! Vous avez trouvé une lettre : {...}")
            else :
                print(F"Dommage ! Cette lettre ne fait pas parti du mot : {...}")
                ...
                traitPendu(...)   
                
            if ... :
                print("\nPERDU !! Vous êtes pendu !!")
                print(F"La réponse était {...}\n")
                partieFinie = ...
                
            elif ... :
                print("\nGAGNE !! Félicitations !!\n")
                print(F"Vous avez trouvé {...}\n")
                partieFinie = ...
            
        jouerEncore = ...

    print("A bientôt !")

...


























